package com.example.demo.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.Entity.Person;
import com.example.demo.Repository.PersonRepository;

@RestController
@RequestMapping("/api/person")
public class PersonController {
	
	@Autowired
	private PersonRepository personRepository;
	
	@PostMapping("/save")
	public Person savePerson (@RequestBody Person person)
	{
		return personRepository.save(person);
	}
	
	@GetMapping("/all")
	public List<Person> getAll(){
		return personRepository.findAll();
		
	}
	
	@PutMapping("/update/{id}")
	public Person updatePerson(@PathVariable Long id , @RequestBody Person person) {
		Person existing = personRepository.findById(id).orElseThrow();
		existing.setName(person.getName());
		existing.setAge(person.getAge());
		return personRepository.save(existing);
		
	}

	@PostMapping("/delete/{id}")
	public String deletePerson(@PathVariable Long id) {
		personRepository.deleteById(id);
		return "Person data deleted successfully";
	}
}
